<?php 
include_once("includes/session.php");
include_once("includes/zz.php"); 
include_once("includes/functions.php");
include_once("models/studentinfo.php");

confirm_logged_in();

$getcountry = "SELECT * FROM countries";
$thecountry = mysqli_query($conn, $getcountry);

$getstate = "SELECT * FROM states";
$thestate = mysqli_query($conn, $getstate);

$matno = $_SESSION['matno'];
$getlogs = "SELECT * FROM eed_logbook WHERE logbookDelete =0 AND logbookMat = '$matno' ORDER BY logbookId DESC";
$thelogs = mysqli_query($conn, $getlogs);
$serial = 1;
$inc = 1;

$getpost = "SELECT * FROM siwespost WHERE siwesMat = '$matno' ORDER BY siwesPostId DESC LIMIT 1";
$thepost = mysqli_query($conn, $getpost);
if($thepost)
{
	$postrow = mysqli_fetch_array($thepost);
}else{
	$postrow['siwesCompName'] = '';
	$postrow['siwesCompAdd'] = '';
	$postrow['siwesCompCountry'] = '';
	$postrow['siwesCompState'] = '';
}
?>
<div class="container wrapper">
	<?php require('views/header.php'); ?>

	<div id="page-content">
		<div class="container">
			<?php include_once('includes/eed_menu.php');?>
			<div class="row">
				<div class="col-sm-8 page-content">
					<div class="white-container mb0">
						<div id='thegentable' class='pb90'>
							<h6>All EED Practical Work Done</h6>
							<?php
							$erroMsg ="";
							if($_SERVER['REQUEST_METHOD'] =='POST'){
								$logbookMat = $_SESSION['matno'];
								$logbookDate = date('Y-m-d');
								$logbookTime = date('H:i:s');
						//$dateofwork = mysqli_real_escape_string($conn,$_POST['dateofwork']);
								$logbookDesc = mysqli_real_escape_string($conn,$_POST['logbookDesc']);

								$permited  = array('jpg', 'jpeg', 'png', 'gif','pdf','doc','docx');
								$file_name = $_FILES['logbookAttach']['name'];
								$file_size = $_FILES['logbookAttach']['size'];
								$file_temp = $_FILES['logbookAttach']['tmp_name'];

								$div = explode('.', $file_name);
								$file_ext = strtolower(end($div));
								$unique_image = substr(md5(time()), 0, 10).'.'.$file_ext;
								$uploaded_image = "attachlogs/eedlogbooks/".$unique_image;

								if($logbookDesc ==""){
									$erroMsg = "<p class='alert alert-danger'>Please enter all fields</p>";
								}elseif ($file_size >1048567) {
									$erroMsg = "<p class='alert alert-danger'>Image Size should be less then 1MB!
									</p>";
								} elseif (in_array($file_ext, $permited) === false) {
									$erroMsg = "<span class='alert alert-danger'>You can upload only:-".implode(', ', $permited)."</span>";
								} else{

									move_uploaded_file($file_temp, $uploaded_image);
									$query = "INSERT INTO eed_logbook (logbookMat, logbookDesc,logbookAttach, logbookDate, logbookTime)VALUES ('$logbookMat', '$logbookDesc','$uploaded_image','$logbookDate', '$logbookTime')";
									$inserted_rows = mysqli_query($conn,$query);
									if ($inserted_rows) {
										$erroMsg = "<p class='alert alert-success'>Data Inserted Successfully.
										</p>";
									}else {
										$erroMsg = "<p class='alert alert-danger'>Data Not Inserted !</p>";
									}
								}
							}
							?>
							<?php if(isset($erroMsg)){ echo $erroMsg;}?>
							<a href="#" id='shownew' class="btn btn-default">Add New Work Done</a>

							<?php if(mysqli_num_rows($thelogs) < 1) {?>
								<p class='pt20 mb90 pb210'>No Work Done added yet.</p>
							<?php }else{?>
								<table class="table-hover">
									<thead>
										<tr>
											<th>S/N</th>
											<th>Date</th>
											<th>Description</th>
											<th></th>
											<th></th>
										</tr>
									</thead>

									<tbody>
										<?php while($logrow = mysqli_fetch_array($thelogs)){ ?>
											<tr>
												<td><?php echo $serial;?></td>				
												<td><?php echo date_format(date_create($logrow['logbookDate']), 'l F j, Y');?></td>
												<td><?php echo $logrow['logbookDesc'];?>
												<?php if($logrow['logbookAttach'] != ''): ?>
													<p><a href='models/downloadfile.php?thedocument=<?php echo $logrow['logbookAttach'];?>' class="btn btn-default" >Download Attachment</a></p><br>							
												<?php endif; ?>
											</td>
											<td><a href="models/eedlogedit.php?log=<?php echo $logrow['logbookId'];?>" class='btn btn-primary fa fa-edit' title='Edit'></a></td>
											<td><a data-href="models/eedlogdelete.php?log=<?php echo $logrow['logbookId'];?>" data-toggle="modal" data-target="#confirm-delete" href="#" class='btn btn-primary fa fa-trash-o' title='Delete'></a></td>

											<!-- Modal Confirmation -->
											<div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
												<div class="modal-dialog">
													<div class="modal-content">
														<form method='post' class='theform' action=''>
															<div class="modal-header">
																<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
																<h4 class="modal-title m0">Confirmation</h4>
															</div>
															<div class="modal-body">
																<p class='black'>Are you sure, you want to delete this work done? If Yes, Give a reason below</p>

																<label>Reason</label>
																<textarea required name='reason' id='reason' ></textarea>
															</div>
															<div class="modal-footer">
																<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
																<button type="submit" class="btn btn-danger themodal danger">Delete</button>                                                                    
															</div>
														</form>
													</div>
												</div>
											</div>
											<!-- End of Modal Confirmation -->

										</tr>
										<?php $serial = $serial + $inc; ?>
									<?php } ?>
								</tbody>
							</table>
						<?php } ?>
					</div>
					<div id='thenew' class='pb60'>

						<form method='post' action="" enctype='multipart/form-data' class='pb50'>
							<fieldset>
								<legend>New Work Done</legend>
							<!-- <label for="">Date of Work</label>
								<input type="text" name="dateofwork" id="dateofwork" class="form-control">	 -->
								<label>
									Description of Work Done:
								</label>
								<textarea name="logbookDesc" id="logbookDesc" rows='5' required></textarea>
								<script>
									CKEDITOR.replace('logbookDesc');
								</script>
								<label class='mt20'>
									Attachment where necessary (For your Sketches, Diagrams and Graphs, upload a document with file types .pdf .doc .docx .xls .xlsx, Max Size: 3mb):
								</label>
								<input type="file" name="logbookAttach">
								<br>
								<input type="submit" name="submit" class="btn btn-default" value='Save'> <a href="#" id='hidenew' class="btn btn-primary" >Cancel</a>
							</fieldset>
						</form>
					</div>
				</div>
			</div>

			<?php include_once('includes/student_side_menu.php');?>
		</div>
	</div> <!-- end .container -->
</div> <!-- end #page-content -->

<?php require('views/footer.php'); ?>
</div>