<?php 
	include_once("includes/session.php");
	include_once("includes/zz.php"); 
    include_once("includes/functions.php");
    include_once("models/studentinfo.php");  

    confirm_logged_in();

    $logbookId = $_SESSION['mylogid'];

    $getlogs = "SELECT * FROM logbook WHERE logbookId = '$logbookId'";
    $thelogs = mysqli_query($conn, $getlogs);
?>
<div class="container wrapper">
	<?php require('views/header.php'); ?>

	<div id="page-content">
		<div class="container">
			<?php include_once('includes/siwes_submenu.php');?>
			<div class="row">
				<div class="col-sm-8 page-content">
					<?php
					if($_SERVER['REQUEST_METHOD'] =='POST'){
						$logbookDesc = mysqli_real_escape_string($conn,$_POST['logbookDesc']);

						$permited  = array('jpg', 'jpeg', 'png', 'gif','pdf','doc','docx');
						$file_name = $_FILES['logbookAttach']['name'];
						$file_size = $_FILES['logbookAttach']['size'];
						$file_temp = $_FILES['logbookAttach']['tmp_name'];

						$div = explode('.', $file_name);
						$file_ext = strtolower(end($div));
						$unique_image = substr(md5(time()), 0, 10).'.'.$file_ext;
						$uploaded_image = "upload/".$unique_image;
						
						if($logbookDesc ==""){
							echo "<p class='alert alert-danger'>Please enter all fields</p>";
						}else{
						if(!empty($file_name)){
							
						
						
						if ($file_size >1048567) {
						 echo "<p class='alert alert-danger'>Image Size should be less then 1MB!
						 </p>";
						} elseif (in_array($file_ext, $permited) === false) {
							echo "<p class='alert alert-danger'>You can upload only:-".implode(', ', $permited)."</p>";
						} else{
							move_uploaded_file($file_temp, $uploaded_image);
							$query = "UPDATE logbook SET logbookDesc    ='".$logbookDesc."', logbookAttach  ='".$uploaded_image."' WHERE logbookId =".$logbookId."";
							$updated_row = mysqli_query($conn,$query);
						if ($updated_row) {
							echo "<p class='alert alert-success'>Data Updated Successfully.
						 </p>";
						}else {
							echo "<p class='alert alert-danger'>Data Not Updated !</p>";
						}
					 }
					}else{
						$query = "UPDATE logbook SET logbookDesc ='".$logbookDesc."' WHERE logbookId =".$logbookId."";
							$updated_row = mysqli_query($conn,$query);
						if ($updated_row) {
							echo "<p class='alert alert-success'>Data Updated Successfully.
						 </p>";
						}else {
							echo "<p class='alert alert-danger'>Data Not Updated !</p>";
					}	}
				}
				}
				?>
					<div class="white-container mb0">
						<?php while($logrow = mysqli_fetch_array($thelogs)){ ?>
							<form method='post' action="" enctype='multipart/form-data' class='pb50'>
								<fieldset>
									<legend>Work Done on <?php echo date_format(date_create($logrow['logbookDate']), 'l F j, Y');?></legend>	
										<label>
											Description of Work Done:
										</label>
										<textarea name="logbookDesc" id="logbookDesc" rows='5' required><?php echo $logrow['logbookDesc'];?></textarea>
                                        <script>
                                            CKEDITOR.replace('logbookDesc');
                                        </script>
										<label class='mt20'>
											Update attachment where necessary (For your Sketches, Diagrams and Graphs, upload a document with file types .pdf .doc .docx .xls .xlsx, Max Size: 3mb):
										</label>
										<input type="file" name="logbookAttach">
									<br>
									<input type="submit" name="submit" class="btn btn-default" value='Save'> <a href="mylogbook.php" class="btn btn-primary" >Cancel</a>
								</fieldset>
							</form>
						<?php } ?>
					</div>
				</div>

			<?php include_once('includes/student_side_menu.php');?>
			</div>
		</div> <!-- end .container -->
	</div> <!-- end #page-content -->

<?php require('views/footer.php'); ?>
</div>