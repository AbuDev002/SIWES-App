<?php 
	include_once("includes/session.php");
	include_once("includes/zz.php"); 
    include_once("includes/functions.php");

    confirm_adminlogged_in();

    $staffno = $_SESSION['staffno'];
    $getadmins = "SELECT * FROM stafflist";
    $thestaffs = mysqli_query($conn, $getadmins);

    $getroles = "SELECT * FROM roles";
    $theroles = mysqli_query($conn, $getroles);

    $getstaff = "SELECT * FROM stafflist WHERE staffno NOT IN ('$staffno')";
    $thestaff = mysqli_query($conn, $getstaff);

    $serial = 1;
    $inc = 1;
?>
<div class="container">
	<?php require('views/header.php'); ?>

	<div id="page-content">
		<div class="container">
			<div class="row">
				<div class="col-sm-8 page-content">
					<div class="white-container mb0">
						<div id='thegentable' class='pb90'>
							<h6>All Staff</h6>
							<a href="#" id='shownew' class="btn btn-default">Add New Staff</a>

							<?php if(mysqli_num_rows($thestaffs) < 1) {?>
							<p class='pt20 mb90 pb210'>No Staff added yet.</p>
							<?php }else{?>
							<table class="table-hover">
								<thead>
									<tr>
										<th>S/N</th>
										<th>Staff No</th>
										<th>Staff Name</th>
										<th></th>
										<th></th>
										
									</tr>
								</thead>

								<tbody>
									<?php while($staffrow = mysqli_fetch_array($thestaffs)){ ?>
									<tr>
										<td><?php echo $serial;?></td>									
										<td><?php echo $staffrow['staffno'];?></td>									
										<td><?php echo ucwords($staffrow['sname']).' '.ucwords($staffrow['fname']).' '.ucwords($staffrow['mname']);?> </td>
										<td><a href="models/adminedit.php?ad=<?php echo $staffrow['staffId'];?>" class='btn btn-primary fa fa-edit' title='Edit'></a></td>
										<td><a href="models/admindelete.php?ad=<?php echo $staffrow['staffId'];?>" class='btn btn-primary fa fa-trash-o' title='Delete'></a></td>
									</tr>
									<?php $serial = $serial + $inc; ?>
									<?php } ?>
								</tbody>
							</table>
							<?php } ?>
						</div>
						<div id='thenew' class='pb60'>
							<form method='post' action="models/newstaff.php" class='pb50'>
								<fieldset>
									<legend>New Staff</legend>	
										<label>
											Staff No:
										</label>
											<input type="text" name="staffno" class="form-control" placeholder="Staff No...">
										<label>
											Password:
										</label>		
										<input type="password" name="password" class="form-control" placeholder="Password...">
										<label>
											Firstname:
										</label>		
										<input type="text" name="fname" class="form-control" placeholder="Firstname...">
										<label>
											Surname:
										</label>		
										<input type="text" name="sname" class="form-control" placeholder="Surname...">
										<label>
											Firstname:
										</label>		
										<input type="text" name="mname" class="form-control" placeholder="Middlename...">
									<br>
									<input type="submit" name="submit" class="btn btn-default" value='Save'> <a href="#" id='hidenew' class="btn btn-primary" >Cancel</a>
								</fieldset>
							</form>
						</div>
					</div>
				</div>

				<div class="col-sm-4 page-sidebar">
					<aside>
						<div class="widget sidebar-widget white-container links-widget">
							<ul>
								<li class="active"><a href="#">Welcome <?php echo $_SESSION['fname'];?></a></li>
								<li><a href="manage_staffs.php">Manage Staffs</a></li>
								<li><a href="manage_students.php">Manage Students</a></li>
								<li><a href="assignment.php">Supervisor Assignments</a></li>
								<li><a href="models/mystudentview.php">My Students</a></li>
								<li><a href="models/adminlogout.php">Log Out</a></li>
							</ul>
						</div>
					</aside>
				</div>
			</div>
		</div> <!-- end .container -->
	</div> <!-- end #page-content -->

<?php require('views/footer.php'); ?>
</div>