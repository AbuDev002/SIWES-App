-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 06, 2021 at 04:10 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `siwes`
--

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `countryid` int(11) NOT NULL,
  `countryname` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `id` int(10) UNSIGNED NOT NULL,
  `department` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `school` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `department`, `description`, `created_at`, `updated_at`, `school`) VALUES
(1, 'AGT', 'Agricultural Technology', '2018-08-09 23:42:48', '2018-08-09 23:42:48', 1),
(2, 'AHP', 'Animal Health And Forestry', '2018-08-09 23:46:02', '2018-08-24 08:19:29', 1),
(3, 'ACCT', 'Accountancy Department', '2018-08-09 23:46:56', '2018-08-09 23:46:56', 2),
(4, 'B&F', 'Banking And Finance', '2018-08-09 23:47:20', '2018-08-09 23:47:20', 2),
(5, 'COMP', 'Computer Science', '2018-08-09 23:48:46', '2018-08-09 23:48:46', 5),
(6, 'FST', 'Food Science And Technology', '2018-08-09 23:49:13', '2018-08-09 23:49:13', 5),
(7, 'SLT', 'Science Laboratory Technology', '2018-09-02 06:55:01', '2018-09-02 06:55:46', 5),
(8, 'LTM', 'LEISURE AND TOURISM MANAGEMENT', '2018-09-02 06:57:46', '2018-09-02 06:57:46', 5),
(9, 'MST', 'MATHEMATICS AND STATISTICS', '2018-09-02 06:59:20', '2018-09-02 06:59:20', 5),
(10, 'NUD', 'NUTRITION AND DIETETICS', '2018-09-02 06:59:53', '2018-09-02 06:59:53', 5),
(11, 'HTM', 'HOSPITALITY MANAGEMENT', '2018-09-02 07:01:37', '2018-09-02 07:01:37', 5),
(12, 'LIS', 'LIBRARY AND INFORMATION SCIENCE', '2018-09-02 07:06:37', '2018-09-02 07:06:37', 4),
(13, 'MACO', 'MASS COMMUNICATION', '2018-09-02 07:07:09', '2018-09-02 07:07:09', 4),
(14, 'PRE_ND', 'Basic Study', '2018-09-02 07:08:53', '2018-09-02 07:53:49', 4),
(15, 'ARCH', 'ARCHITECTURAL TECHNOLOGY', '2018-09-02 07:10:03', '2018-09-02 07:10:03', 6),
(16, 'BLD', 'BUILDING TECHNOLOGY', '2018-09-02 07:10:54', '2018-09-02 07:10:54', 6),
(17, 'EST', 'ESTATE MANAGEMENT', '2018-09-02 07:11:29', '2018-09-02 07:11:29', 6),
(18, 'QS', 'QUANTITY SURVEY', '2018-09-02 07:12:34', '2018-09-02 07:12:34', 6),
(19, 'DSUG', 'SURVEYING AND GEO-INFORMATICS', '2018-09-02 07:13:21', '2018-09-02 07:13:21', 6),
(20, 'ABE', 'AGRICULTURAL & BIO-ENVIRONMENTAL ENGINEERING', '2018-09-02 07:21:10', '2018-09-02 07:50:13', 3),
(21, 'CVET', 'CIVIL ENGINEERING TECHNOLOGY', '2018-09-02 07:22:15', '2018-09-02 07:52:27', 3),
(22, 'EEET', 'ELECTRICALELECTRONIC ENGINEERING', '2018-09-02 07:22:45', '2018-09-02 07:22:45', 3),
(23, 'MECH', 'MECHANICAL ENGINEERING TECHNOLOGY', '2018-09-02 07:23:27', '2018-09-02 07:23:27', 3),
(24, 'BFN', 'BANKING AND FINANCE', '2018-09-02 07:24:16', '2018-09-02 07:24:16', 2),
(25, 'BAM', 'BUSINESS ADMINISTRATION AND MANAGEMENT', '2018-09-02 07:24:45', '2018-09-02 07:24:45', 2),
(26, 'MKT', 'MARKETING', '2018-09-02 07:25:14', '2018-09-02 07:25:14', 2),
(27, 'OTM', 'OFFICE TECHNOLOGY & MANAGEMENT', '2018-09-02 07:25:44', '2018-09-02 07:25:44', 2),
(28, 'PAD', 'PUBLIC ADMINISTRATION', '2018-09-02 07:26:23', '2018-09-02 07:26:23', 2),
(29, 'FOT', 'FORESTRY', '2018-09-02 07:27:17', '2018-09-02 07:27:17', 1),
(30, 'DREC', 'DEPUTY RECTOR\'S OFFICE', '2018-09-02 07:31:43', '2018-09-02 07:31:43', 7),
(31, 'CMC', 'CRIME MANAGEMENT AND CONTROL', '2018-09-02 07:48:40', '2018-09-02 07:48:40', 4),
(32, 'Rectory', 'Rectory', '2018-10-09 09:36:54', '2018-11-08 09:09:23', 7),
(33, 'BURSARY', 'BURSARY', '2018-11-08 08:00:43', '2018-11-08 08:00:43', 7),
(34, 'WORKS', 'WORKS', '2018-11-08 08:01:47', '2018-11-08 08:01:47', 7),
(35, 'GNS', 'GENERAL STUDIES', '2018-11-08 08:39:10', '2018-11-08 08:39:10', 4),
(36, 'D/Rect', 'Deputy Rector Office', '2018-11-08 09:13:57', '2018-11-08 09:13:57', 7),
(37, 'ICT/MIS', 'Management Inf. System Directorate', '2018-11-08 09:15:12', '2018-11-08 09:15:12', 7),
(38, 'PPU', 'Physical Planing Unit', '2018-11-08 09:16:18', '2018-11-08 09:16:18', 7),
(39, 'MWL', 'Muhammed Wabi Library', '2018-11-08 09:31:45', '2018-11-08 09:31:45', 7),
(40, 'Estab', 'Establishment', '2018-11-08 11:20:38', '2018-11-08 11:20:38', 8),
(41, 'Student Affairs', 'Student Affairs', '2018-11-08 11:21:33', '2018-11-08 11:21:33', 8),
(42, 'Academics', 'Registry Academis Division', '2018-11-08 11:22:27', '2018-11-08 11:22:27', 8);

-- --------------------------------------------------------

--
-- Table structure for table `eed_logbook`
--

CREATE TABLE `eed_logbook` (
  `logbookId` int(11) NOT NULL,
  `logbookMat` varchar(255) NOT NULL,
  `logbookDesc` varchar(255) NOT NULL,
  `logbookAttach` varchar(255) NOT NULL,
  `logbookComment` varchar(255) NOT NULL,
  `logDeleteReason` varchar(255) NOT NULL,
  `logbookDelete` varchar(255) NOT NULL DEFAULT '0',
  `logbookDate` varchar(255) NOT NULL,
  `logbookTime` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `eed_logbook`
--

INSERT INTO `eed_logbook` (`logbookId`, `logbookMat`, `logbookDesc`, `logbookAttach`, `logbookComment`, `logDeleteReason`, `logbookDelete`, `logbookDate`, `logbookTime`) VALUES
(1, '18/2021', '<p>this is good this is good this is good</p><p>&nbsp;</p>', 'attachlogs/eedlogbooks/8a5b4fbbf2.pdf', '', '', '0', '2021-08-14', '10:35:37'),
(2, '18/2021', '<p>Another another another thing</p>', 'attachlogs/eedlogbooks/42e554391c.pdf', '', 'Not relevant', '1', '2021-08-14', '18:50:14');

-- --------------------------------------------------------

--
-- Table structure for table `eed_trade`
--

CREATE TABLE `eed_trade` (
  `id` int(11) NOT NULL,
  `std_name` varchar(255) NOT NULL,
  `std_matricno` varchar(255) NOT NULL,
  `std_dept` varchar(255) NOT NULL,
  `std_class` varchar(255) NOT NULL,
  `std_session` varchar(255) NOT NULL,
  `std_trade` varchar(255) NOT NULL,
  `std_email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `eed_trade`
--

INSERT INTO `eed_trade` (`id`, `std_name`, `std_matricno`, `std_dept`, `std_class`, `std_session`, `std_trade`, `std_email`) VALUES
(1, 'rgsdfg', 'dsfgdsf', 'dsfgdf', 'sdfgdg', 'sdfg', 'sdfgf', 'dfhgf');

-- --------------------------------------------------------

--
-- Table structure for table `logbook`
--

CREATE TABLE `logbook` (
  `logbookId` int(11) NOT NULL,
  `logbookMat` varchar(255) DEFAULT NULL,
  `logbookDesc` text DEFAULT NULL,
  `logbookAttach` varchar(255) DEFAULT NULL,
  `logbookComment` text DEFAULT NULL,
  `logDeleteReason` varchar(255) DEFAULT NULL,
  `logbookDelete` int(11) DEFAULT 0,
  `logbookDate` date DEFAULT current_timestamp(),
  `logbookTime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `logbook`
--

INSERT INTO `logbook` (`logbookId`, `logbookMat`, `logbookDesc`, `logbookAttach`, `logbookComment`, `logDeleteReason`, `logbookDelete`, `logbookDate`, `logbookTime`) VALUES
(1, '18/2021', '<p>nothing nothing nothing</p>', 'attachlogs/88d6bb5082.pdf', NULL, 'not okay', 1, '2021-08-13', '2021-08-14 10:51:37'),
(2, '18/2021', '<p>another record of logbook</p>', 'attachlogs/3c5375ebdf.pdf', NULL, NULL, 0, '2021-08-13', '2021-08-13 13:40:40'),
(3, '18/2021', '<p>dgsdhdfgh</p>', 'attachlogs/c635f6f604.pdf', NULL, 'Poor report', 1, '2021-08-13', '2021-08-13 13:43:44'),
(4, '18/2021', '<p>this is the original report</p>', 'attachlogs/c7bb3d6c31.pdf', NULL, 'Report not relevance', 1, '2021-08-13', '2021-08-13 18:10:37'),
(5, '18/2021', '<p>The federal polytechnic bauchi</p>', 'attachlogs/da27a6d90f.pdf', NULL, NULL, 0, '2021-08-13', '2021-08-13 17:40:10'),
(6, '18/111', '<p>Today i have learn how to insert data into the database. and how to retrieve record form the database</p>', 'attachlogs/e0703dd4e2.pdf', '<p>That is a very good job. keep it up and you will excel</p>', NULL, 0, '2021-08-15', '2021-08-15 16:23:10'),
(7, '15/39434u/5', '<p>SDGDFGDFGFDGDFGHF</p>', 'attachlogs/d116492cf6.jpg', NULL, NULL, 0, '2021-10-06', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `reglist`
--

CREATE TABLE `reglist` (
  `id` int(11) NOT NULL,
  `matno` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `sname` varchar(100) NOT NULL,
  `mname` varchar(100) NOT NULL,
  `fno` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `sex` varchar(100) NOT NULL,
  `college` varchar(100) NOT NULL,
  `dept` varchar(100) NOT NULL,
  `program` varchar(100) NOT NULL,
  `yog` varchar(100) NOT NULL,
  `level` varchar(100) NOT NULL,
  `nationality` varchar(100) NOT NULL,
  `bank_account` varchar(100) NOT NULL,
  `student_passport` varchar(100) NOT NULL,
  `studentshipStatus` varchar(100) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reglist`
--

INSERT INTO `reglist` (`id`, `matno`, `password`, `fname`, `sname`, `mname`, `fno`, `email`, `sex`, `college`, `dept`, `program`, `yog`, `level`, `nationality`, `bank_account`, `student_passport`, `studentshipStatus`) VALUES
(3, '18/111', '5f4dcc3b5aa765d61d8327deb882cf99', 'Fatima', 'Alhassan', 'Musa', '09038474336', 'aam@gmail.com', '', '', '', '', '', '', 'Nigeria', '0985746434', 'upload/2195a68728.png', 'Active'),
(4, '18/1000', '5f4dcc3b5aa765d61d8327deb882cf99', 'Ismail', 'Adamu', 'Yakasai', '', '', '', '', '', '', '', '', '', '', '', 'Active'),
(5, '18/9999', '5f4dcc3b5aa765d61d8327deb882cf99', 'Abdullahi', 'Yakubu', 'Ahmad', '08049484734', 'yaa@gmail.com', '', '', '', '', '', '', 'Nigeria', '58574857473', 'upload/afd2f218bb.png', 'Active'),
(6, '18/4040', '5f4dcc3b5aa765d61d8327deb882cf99', 'Aliyu', 'Garba', 'Lawal', '', '', '', '', '', '', '', '', '', '', '', 'Active'),
(7, '18/5959', '5f4dcc3b5aa765d61d8327deb882cf99', 'Kamaludeen', 'Usman', 'Aliyu', '07094847473', 'uka@gmail.com', '', '', '', '', '', '', 'Nigeria', '58775446', 'upload/e4621ca336.png', 'Active'),
(8, '15/39434u/5', '5f4dcc3b5aa765d61d8327deb882cf99', 'Jamila', 'Sulaiman', '', '090384847744', 'jamila@gmail.com', '', '', '', '', '', '', 'Nigeria', '36456546', 'upload/8a133f43de.jpg', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `roleId` int(11) NOT NULL,
  `roleName` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`roleId`, `roleName`) VALUES
(1, 'Admin'),
(2, 'Supervisor');

-- --------------------------------------------------------

--
-- Table structure for table `siwespost`
--

CREATE TABLE `siwespost` (
  `siwesPostId` int(11) NOT NULL,
  `siwesCourse` varchar(255) DEFAULT NULL,
  `siwesMat` varchar(100) NOT NULL,
  `siwesSemester` varchar(255) DEFAULT NULL,
  `siwesOfficer` int(11) NOT NULL,
  `siwesCompName` varchar(255) DEFAULT NULL,
  `siwesCompAdd` text DEFAULT NULL,
  `siwesCompCountry` varchar(255) DEFAULT NULL,
  `siwesCompState` varchar(255) DEFAULT NULL,
  `siwesSupervisor` varchar(255) DEFAULT NULL,
  `siwesSupervisorNo` varchar(255) DEFAULT NULL,
  `siwesSupervisorNoAdd` varchar(255) NOT NULL,
  `siwesStartDate` varchar(100) NOT NULL,
  `siwesDuration` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `siwespost`
--

INSERT INTO `siwespost` (`siwesPostId`, `siwesCourse`, `siwesMat`, `siwesSemester`, `siwesOfficer`, `siwesCompName`, `siwesCompAdd`, `siwesCompCountry`, `siwesCompState`, `siwesSupervisor`, `siwesSupervisorNo`, `siwesSupervisorNoAdd`, `siwesStartDate`, `siwesDuration`) VALUES
(1, 'Computer Programming', '18/2021', 'First Semester', 0, 'Connect Center', 'Ahmadu Bello Way Bauchi', 'Nigeria', 'Bauchi', 'Usman Muhammed', '0908474434', 'Bauchi', '2021-08-16', '6 month'),
(2, 'Database Management', '18/111', 'Second Semester', 2070, 'ATBU Teaching Hospital', 'Abubakar Tafawa Balewa University', 'Nigeria', 'Bauchi', 'Hafizu Musa', '09038484743', 'ICT Unit ATButh', '2021-08-15', '6 month'),
(3, 'Database Management', '18/9999', 'First Semester', 3430, 'Professor Iya Abubakar Community Resources', 'Bank Road Bauchi', 'Nigeria', 'Bauchi', 'Ahmad Abdullahi', '090847474', 'CRC Bauchi', '2021-08-17', '1 year'),
(4, 'Database Management', '18/5959', 'First Semester', 2070, 'Dipol Laboratory', 'Investiment Complext Bauchi', 'Nigeria', 'Bauchi', 'M Joseph', '0709487473', 'Diplo Laboratory ', '2021-08-16', '1 year'),
(5, 'Computer Programming', '15/39434u/5', 'First Semester', 3333, 'JMT IT solution', 'sdgdsgfs', 'Nigeria', 'Bauchi', 'Musa Musa', '08048474743', 'sdfsd', '2021-10-06', '6 month');

-- --------------------------------------------------------

--
-- Table structure for table `stafflist`
--

CREATE TABLE `stafflist` (
  `staffId` int(11) NOT NULL,
  `staffno` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `fname` varchar(255) DEFAULT NULL,
  `sname` varchar(255) DEFAULT NULL,
  `mname` varchar(255) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `college` varchar(255) DEFAULT NULL,
  `dept` varchar(255) DEFAULT NULL,
  `program` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stafflist`
--

INSERT INTO `stafflist` (`staffId`, `staffno`, `password`, `fname`, `sname`, `mname`, `sex`, `college`, `dept`, `program`) VALUES
(1, '2070', '5f4dcc3b5aa765d61d8327deb882cf99', 'User 1', 'user1', '', 'F', 'Abubakar Tafawa Balawa University Bauchi', 'Computer Science', 'B.Tech'),
(2, '2320', '5f4dcc3b5aa765d61d8327deb882cf99', 'Abubakar', 'Ahmad', 'Yusuf', 'M', 'Abubakar Tafawa Balewa University Bauchi', 'Computer Science', 'B.Tech'),
(4, '3333', '5f4dcc3b5aa765d61d8327deb882cf99', 'Jambil', 'Hassan', '', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `staffrole`
--

CREATE TABLE `staffrole` (
  `staffRoleId` int(11) NOT NULL,
  `staffNum` varchar(255) DEFAULT NULL,
  `staffRoleNo` int(11) DEFAULT NULL,
  `loginTime` datetime DEFAULT NULL,
  `staffDelete` varchar(255) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staffrole`
--

INSERT INTO `staffrole` (`staffRoleId`, `staffNum`, `staffRoleNo`, `loginTime`, `staffDelete`) VALUES
(1, '2070', 1, '2021-10-06 16:06:51', '0'),
(2, '2320', 2, '2021-08-15 12:51:17', '0'),
(4, '3430', 2, '2021-08-15 17:53:27', '0'),
(5, '3333', 2, '2021-10-06 15:49:14', 'Yes'),
(6, '3333', 2, '2021-10-06 16:07:03', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE `state` (
  `id` int(12) NOT NULL COMMENT 'The primary key',
  `state` varchar(20) NOT NULL COMMENT 'The state'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`id`, `state`) VALUES
(1, 'Abia State'),
(2, 'Adamawa State'),
(3, 'Akwa Ibom State'),
(4, 'Anambra State'),
(5, 'Bauchi State'),
(6, 'Bayelsa State'),
(7, 'Benue State'),
(8, 'Borno State'),
(9, 'Cross River State'),
(10, 'Delta State'),
(11, 'Ebonyi State'),
(12, 'Edo State'),
(13, 'Ekiti State'),
(14, 'Enugu State'),
(15, 'FCT'),
(16, 'Gombe State'),
(17, 'Imo State'),
(18, 'Jigawa State'),
(19, 'Kaduna State'),
(20, 'Kano State'),
(21, 'Katsina State'),
(22, 'Kebbi State'),
(23, 'Kogi State'),
(24, 'Kwara State'),
(25, 'Lagos State'),
(26, 'Nasarawa State'),
(27, 'Niger State'),
(28, 'Ogun State'),
(29, 'Ondo State'),
(30, 'Osun State'),
(31, 'Oyo State'),
(32, 'Plateau State'),
(33, 'Rivers State'),
(34, 'Sokoto State'),
(35, 'Taraba State'),
(36, 'Yobe State'),
(37, 'Zamfara State');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`countryid`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eed_logbook`
--
ALTER TABLE `eed_logbook`
  ADD PRIMARY KEY (`logbookId`);

--
-- Indexes for table `eed_trade`
--
ALTER TABLE `eed_trade`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logbook`
--
ALTER TABLE `logbook`
  ADD PRIMARY KEY (`logbookId`);

--
-- Indexes for table `reglist`
--
ALTER TABLE `reglist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`roleId`);

--
-- Indexes for table `siwespost`
--
ALTER TABLE `siwespost`
  ADD PRIMARY KEY (`siwesPostId`);

--
-- Indexes for table `stafflist`
--
ALTER TABLE `stafflist`
  ADD PRIMARY KEY (`staffId`);

--
-- Indexes for table `staffrole`
--
ALTER TABLE `staffrole`
  ADD PRIMARY KEY (`staffRoleId`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `countryid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `eed_logbook`
--
ALTER TABLE `eed_logbook`
  MODIFY `logbookId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `eed_trade`
--
ALTER TABLE `eed_trade`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `logbook`
--
ALTER TABLE `logbook`
  MODIFY `logbookId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `reglist`
--
ALTER TABLE `reglist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `roleId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `siwespost`
--
ALTER TABLE `siwespost`
  MODIFY `siwesPostId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `stafflist`
--
ALTER TABLE `stafflist`
  MODIFY `staffId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `staffrole`
--
ALTER TABLE `staffrole`
  MODIFY `staffRoleId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `state`
--
ALTER TABLE `state`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT COMMENT 'The primary key', AUTO_INCREMENT=38;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
