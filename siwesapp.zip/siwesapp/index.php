<?php 
	include_once("includes/session.php");
	include_once("includes/zz.php"); 
    include_once("includes/functions.php"); 

	if(isset($_POST['submit']))
	{
		$matno = $_POST['matno'];
		$password = $_POST['password'];
		$pass_hash = md5($password);

            // Search for matric
            $getstdnt = "SELECT * FROM reglist WHERE matno='$matno' AND password='$pass_hash'";
            $stdnt = mysqli_query($conn, $getstdnt);
            confirm_query($stdnt);

            if(mysqli_num_rows($stdnt) < 1)
            {
            	// Invalid Matric Number
            	$incorrectLogin = 'Matric No. or Reg No. Incorrect';
            }else
            {
            	// Valid Matric Number
            	$_SESSION['matno'] = $matno;
                $_SESSION['is_logged_in'] = true;
            	header("Location:siwes.php");
            }
	}
?>

<div class="container wrapper">
	
	<?php require('views/header.php'); ?>

	<div id="page-content">
		<div class="container">
			<div class="row">
				<div class="col-sm-8 page-content">
					<img src="assets/img/atbulogo.jpg" alt="">
				</div>

				<div class="col-sm-4 page-sidebar">
					<aside>
						<div class="widget sidebar-widget white-container contact-form-widget">
							<h5 class="widget-title" style="display:inline;">Sign In</h5>
							<div style="text-align:right;margin-top:-20px;">
								<a href="siwesadmin.php"><i class="fa fa-user"></i></a>
							</div>
							<div class="widget-content">
								<?php if(isset($incorrectLogin)): ?>
										<div class='alert alert-error'>
											<h6><?php echo $incorrectLogin;?></h6>
											<a href='#' class='close fa fa-times'></a>
										</div>
								<?php endif; ?>
								<form class="mt30" action='' method='POST'>
									<div class="form-group">
										<input type="text" class="form-control" placeholder="Username" name='matno' required >
										<input type="password" class="form-control" placeholder="Password" name='password' required >
									</div>

									<button type="submit" class="btn btn-default" name='submit'><i class="fa fa-lock"></i> Sign In</button>
								</form>
							</div>
						</div>
					</aside>
				</div>
			</div>
		</div> <!-- end .container -->
	</div> <!-- end #page-content -->

<?php require('views/footer.php'); ?>
</div>