<?php 
include_once("includes/session.php");
include_once("includes/zz.php"); 
include_once("includes/functions.php");
include_once("models/studentinfo.php");

confirm_logged_in();

$getcountry = "SELECT * FROM countries";
$thecountry = mysqli_query($conn, $getcountry);

$getstate = "SELECT * FROM states";
$thestate = mysqli_query($conn, $getstate);

$getpost = "SELECT * FROM siwespost WHERE siwesMat = '$matno' ORDER BY siwesPostId DESC LIMIT 1";
$thepost = mysqli_query($conn, $getpost);
if($thepost)
{
	$postrow = mysqli_fetch_array($thepost);
}else{
	$postrow['siwesCompName'] = '';
	$postrow['siwesCompAdd'] = '';
	$postrow['siwesCompCountry'] = '';
	$postrow['siwesCompState'] = '';
}
?>
<div class="container wrapper">
	<?php require('views/header.php'); ?>

	<div id="page-content">
		<div class="container">
			<?php include_once('includes/eed_menu.php');?>
			<div class="row">
				<div class="col-sm-8 page-content">
					<div class="white-container mb0">
						<h4>SKILL ACQUISITION AND PRACTICAL TRAINNING</h4>
						<?php
					if($_SERVER['REQUEST_METHOD'] =='POST'){
						$std_name = mysqli_real_escape_string($conn,$_POST['std_name']);
						$std_matricno = mysqli_real_escape_string($conn,$_POST['std_matricno']);
						$std_department = mysqli_real_escape_string($conn,$_POST['std_department']);
						$std_class = mysqli_real_escape_string($conn,$_POST['std_class']);
						$std_session = mysqli_real_escape_string($conn,$_POST['std_session']);
						$std_trade = mysqli_real_escape_string($conn,$_POST['std_trade']);
						$std_email = mysqli_real_escape_string($conn,$_POST['std_email']);
						
						
						if($std_name =="" || $std_matricno =="" || $std_department =="" || $std_class =="" || $std_session =="" || $std_trade =="" || $std_email ==""){
							echo "<p class='alert alert-danger'>Please enter all fields</p>";
						} else{
							$query = "INSERT INTO eed_trade(std_name,std_matricno,std_dept,std_class,std_session,std_trade,std_email) VALUES('".$std_name."','".$std_matricno."','".$std_department."','".$std_class."','".$std_session."','".$std_trade."','".$std_email."')";
							
							$inserted_rows = mysqli_query($conn,$query);
						if ($inserted_rows) {
							echo "<p class='alert alert-success'>Data Inserted Successfully.
						 </p>";
						}else {
							echo "<p class='alert alert-danger'>Data Not Inserted !</p>";
						}
					}
				}
				?>
						<form action="" method="post">

							<div class="form-group">
								<label for="exampleInputEmail1">Name of Student</label>
								<input type="text" name="std_name" class="form-control" id="noa" placeholder="Student Name...">
							</div>
							<div class="form-group">
								<label for="exampleInputEmail1">Matric no.</label>
								<input type="text" name="std_matricno" class="form-control" id="noa" placeholder="Matric no...">
							</div>
							<div class="form-group">
								<label for="exampleInputEmail1">Department</label>
								 <select id="std_department" name="std_department" class="form-control">
                                    <option value="">--Select Department--</option>
									<?php
									 $getdept_sql ="SELECT * FROM department";
									 $getdept_qry = mysqli_query($conn, $getdept_sql);
									 if($getdept_qry){
									 while($getdept_rs = mysqli_fetch_array($getdept_qry)){
									
									?>
									<option value="<?php echo $getdept_rs['id']?>"><?php echo $getdept_rs['department'];?></option>
									<?php } } ?>
                                </select>
							</div>
							<div class="form-group">
								<label for="exampleInputEmail1">Class</label>
								<!-- <input type="text" name="std_class" class="form-control" id="noa" placeholder="Class..."> -->
								<select name="std_class" id="std_class" class="form-control">
									<option value="">--Select Class--</option>
									<option value="HND II">HND II</option>
									<option value="HND I">HND I</option>
									<option value="ND II">ND II</option>
									<option value="ND I">ND I</option>
								</select>
							</div>
							<div class="form-group">
								<label for="exampleInputEmail1">Session</label>
								<input type="text" name="std_session" class="form-control" id="noa" placeholder="Session...">
							</div>
							<div class="form-group">
								<label for="exampleInputEmail1">Skill Trade / Unit</label>
								<input type="text" name="std_trade" class="form-control" id="noa" placeholder="Skill trade/Unit...">
							</div>
							<div class="form-group">
								<label for="exampleInputEmail1">Email</label>
								<input type="text" name="std_email" class="form-control" id="noa" placeholder="Email...">
							</div>
							<div class="form-group">
								<button type="submit" class="btn btn-primary">Save Record</button>
							</div>
						</form>
					</div>
				</div>

				<?php include_once('includes/student_side_menu.php');?>
			</div>
		</div> <!-- end .container -->
	</div> <!-- end #page-content -->

	<?php require('views/footer.php'); ?>
</div>