<ul class="nav nav-tabs">
	<li role="presentation" class="<?php echo basename($_SERVER['PHP_SELF']) == 'personal_details.php' ? 'active' : '';?>"><a href="personal_details.php">Personal Details</a></li>
	<li role="presentation" class="<?php echo basename($_SERVER['PHP_SELF']) == 'siwes_details.php' ? 'active' : '';?>"><a href="siwes_details.php">Siwes Details</a></li>
	<li role="presentation" class="<?php echo basename($_SERVER['PHP_SELF']) == 'supervisor_details.php' ? 'active' : '';?>"><a href="supervisor_details.php">Supervision</a></li>
	<li role="presentation" class="<?php echo basename($_SERVER['PHP_SELF']) == 'mylogbook.php' ? 'active' : '';?>"><a href="mylogs.php">Report/Log Book</a></li>
</ul>