<div class="col-sm-4 page-sidebar">
<aside>
	<div class="widget sidebar-widget white-container links-widget">
		<ul>
			<li class="active"><a href="#">Welcome <?php echo ucwords($fname);?></a></li>
			<li><a href="siwes.php">SIWES Promgram</a></li>			
			<!-- <li><a href="eed_program.php">EED Program</a></li> -->			
			<li><a href="models/logout.php">Log Out</a></li>
		</ul>
	</div>
</aside>
</div>