<?php
require("constants.php");

	$conn = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);
	if(!$conn){
		die("Database connection failed: " . mysqli_error($conn));
	}
	
	// $db_select = mysql_select_db(DB_NAME,$connection);
	// if(!$db_select){
	// 	die("Database selection failed: " . mysql_error());
	// }
?>