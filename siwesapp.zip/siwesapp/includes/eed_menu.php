<ul class="nav nav-tabs">
	<li role="presentation" class="<?php echo basename($_SERVER['PHP_SELF']) == 'eed_program.php' ? 'active' : '';?>"><a href="eed_program.php">Trade Registration</a></li>
	<li role="presentation" class="<?php echo basename($_SERVER['PHP_SELF']) == 'eed_logbook.php' ? 'active' : '';?>"><a href="eed_logbook.php">Report/Log Book</a></li>
</ul>